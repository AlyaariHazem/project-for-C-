﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem27
{
    public class Visit
    {
        public Customer customer { get; set; }
        private DateTime date;
        private double serviceExpense;
        private double productExpense;

        public Visit(string name, DateTime date)
        {
            customer = new Customer(name);
            this.date = date;
        }

        public string getName()
        {
            return customer.getName();
        }

       
        public double getProductExpense()
        {
            return productExpense;
        }

        public void setProductExpense(double pExpense)
        {
            productExpense = pExpense;
        }

        public double getServiceExpense()
        {
            return serviceExpense;
        }

        public void setServiceExpense(double ServiceExpense)
        {
            this.serviceExpense = ServiceExpense;
        }

        public double getTotalExpense()
        {

            return getServiceExpense()
                - (getServiceExpense() * DiscountRate.getServiceDiscount(customer.getMemberType()))
                + getServiceExpense()
                - (getProductExpense() * DiscountRate.getProductDiscount(customer.getMemberType()));


        }

        public string toString()
        {
            string[] lines = { $"Name:{getName()}", customer.isMember()?$"this customer is member ":$"this customer is not member",$"Total cost :{getTotalExpense()}" };
            return string.Join("\n", lines);
        }
    }
}