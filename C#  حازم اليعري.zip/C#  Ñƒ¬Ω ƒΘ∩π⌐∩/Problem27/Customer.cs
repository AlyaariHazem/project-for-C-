﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem27
{
    public enum CostumerType
    {
        Premium,Silver,Gold
    }
    public class Customer
    {
        private string name;
        private bool member=false;
        private string memberType;

        /// <summary>
        /// class Constructer
        /// </summary>
        public Customer(string name)
        {
            this.name = name;
            Visits = new List<Visit>();
        }

        public List<Visit> Visits
        {
            get;set;
        }

        public string getName()
        {
            return name;
        }

        public bool isMember()
        {
            return member;
        }

        public void setMember(bool member)
        {
            this.member = member;
        }

        public void setMemberType(string type)
        {
            this.memberType = type;
        }

        public string getMemberType()
        {
            return memberType;
        }

        public void toString()
        {
          
        }
    }
}