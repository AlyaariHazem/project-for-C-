﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem27
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Visit visit = new Visit("Hazem", DateTime.Now);
            visit.customer.setMemberType("apples");
            visit.customer.setMember(true);
            visit.setProductExpense(838);
            visit.setServiceExpense(663);
            Console.WriteLine(visit.toString());

        }
    }
}
