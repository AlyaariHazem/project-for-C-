﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace Problem30
{
    internal class Program
    {
        static void Main(string[] args)
        {
            MyComplex mycomplex=new MyComplex();
            mycomplex.SetValue(1, 2);   
            MyComplex myComplex=new MyComplex();
            myComplex.SetValue(3, 4);   
            myComplex.Add(mycomplex);

            Console.WriteLine(myComplex.toString());
        }
    }
}
