﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem30
{
    public class MyComplex
    {
        private double real;
        private double imag;

        public MyComplex()
        {

        }

        public double GetReal()
        {
            return real;
        }

        public double GetImag()
        {
            return imag;
        }

        public void SetReal(double num)
        {
            real = num;
        }

        public void SetImag(double num)
        {
            imag = num;
        }

        public MyComplex Add(MyComplex right)
        {
            real += right.GetReal();
            imag += right.GetImag();
            return this;
        }

        public MyComplex Substract(MyComplex right)
        {
            real -= right.GetReal();
            imag -= right.GetImag();
            return this;
        }

        public MyComplex Multiply(MyComplex right)
        {
            real = (real * right.GetReal() - imag * right.GetImag());
            imag = (imag * right.GetReal() + real * right.GetImag());
            return this;
        }

        public MyComplex Divide(MyComplex right)
        {
            Multiply(Conj());
            right = right.Multiply(right.Conj());

            return this;
        }

        public MyComplex AddNew(MyComplex right)
        {
            MyComplex myComplex = new MyComplex();

            myComplex.real += right.GetReal();
            myComplex.imag += right.GetImag();
            return myComplex;
        }

        public MyComplex SubNew(MyComplex right)
        {
            MyComplex myComplex = new MyComplex();

            myComplex.real -= right.GetReal();
            myComplex.imag -= right.GetImag();
            return myComplex;
        }

        public bool IsReal()
        {
            if (GetImag() == 0)
            {
                return true;
            }
            return false;
        }

        public bool IsImaginary()
        {
            if (GetImag() != 0)
            {
                return true;

            }
            return false;
        }

        public bool Equals(double real, double imaginary)
        {
            if (real == imaginary)
            {
                return true;
            }
            return false;
        }

        public bool Equals(MyComplex another)
        {
            if (real == another.real && GetImag() == another.GetImag())
            {
                return true;

            }
            return false;
        }

        public void SetValue(double real, double imaginary)
        {
            this.real = real;
            this.imag = imaginary;
        }

        public String toString()
        {
            if (imag < 0)
            {
                return ("The resault is " + $"{real}{imag}i");
            }

            else
            {
                return ("The resault is " + $"{real}+{imag}i");
            }
        }

        public MyComplex Conj()
        {
            imag = -1 * imag;
            return this;
        }

        public double Magnitude()
        {
            return Math.Sqrt(Math.Pow(real, 2) + Math.Pow(imag, 2));
        }

        public double Argument()
        {
            return Math.Asin(imag / Magnitude());
        }
    }
}