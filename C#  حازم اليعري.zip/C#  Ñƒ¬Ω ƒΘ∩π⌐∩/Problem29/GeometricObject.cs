﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem29_1
{
    public interface GeometricObject
    {
        double GetArea();
        double GetPerimeter();
    }
}