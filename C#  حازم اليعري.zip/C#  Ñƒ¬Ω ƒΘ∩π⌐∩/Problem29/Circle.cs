﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem29_1
{
    public class Circle : GeometricObject
    {
        public Circle(double Radiu)
        {
          Radius = Radiu;
        }

        protected static double Radius;

        public double GetArea()
        {
         return   Math.Pow((Math.PI * Radius), 2);
        }

        public double GetPerimeter()
        {
            return 2 * Math.PI * Radius;
        }

        public virtual string toString()
        {
            return $"Circle radius :{Radius}";
        }
    }
}