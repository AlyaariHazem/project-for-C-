﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem29_1
{
    public class ResizibleCircle : Circle, Resizable
    {
        public ResizibleCircle(double radius) : base(Radius)
        {
            Radius = radius;
        }
        public void Resize(double percent)
        {
            Radius *= percent / 100;
        }

        public override string toString()
        {
            return $"Resizible Circle Radius :{Radius}";
        }
     
    }
}