﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem31
{
    public class Account
    {
        private int id;
        private Customer customer;
        private double balance;

        public Account(int id, Customer customer, double balance)
        {
            this.id = id;
            this.customer = customer;
            this.balance = balance;

        }

        public Account(int id, Customer customer)
        {

            this.id = id;
            this.customer = customer;
        }

        public int GetId()
        {
            return id;
        }

        public double GetBalance()
        {
            return balance;
        }

        public void SetBalance(double balance)
        {
            this.balance = balance;
        }

        public Customer GetCustomer()
        {
            return customer;
        }

        public string GetCustomerName()
        {
            return customer.Name;
        }

        public Account Diposite(double amount)
        {
            balance += amount;
            return this;
        }

        public Account Withdraw(double amount)
        {
            if(amount<=balance)
            {
                balance -= amount;
            }
            else
            {
                Console.WriteLine("you have notenaugh balance!");
            }
            return this;
        }

        public string ToString()
        {
            return $"Name {customer.Name} Id:{id}\n total balance : {balance}";
        }
    }
}