﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem31
{
  


internal class Program
    {
        static void Main(string[] args)
        {
            Customer customer = new Customer();
            customer.Name = "Test";
            Account account = new Account(0,customer,3245);
            account.Diposite(54);
            account.Withdraw(500);
            Console.WriteLine(account.ToString());
        }
    }
}
