﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem28
{
    public class BigDog : Dog
    {
        public BigDog(string Name):base(name)
        {

        }

        public void Greets(BigDog another)
        {
            Console.WriteLine("big dog");
        }
        public override void Greets()
        {
            Console.WriteLine("small dog");
        }
        public override void Greets(Dog another)
        {
            Console.WriteLine("middle dog");
        }
    }
}