﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem28
{
 
    public abstract class Animal
    {
        protected static string name { get; set; }
        public Animal(string  name)
        {
           
        }

        public abstract void  Greets();
        
    }
}