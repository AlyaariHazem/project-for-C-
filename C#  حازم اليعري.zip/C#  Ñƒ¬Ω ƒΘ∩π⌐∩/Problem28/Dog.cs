﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem28
{
    public class Dog : Animal
    {
        public Dog(string Name) : base(name)
        {
         
        }

        public virtual void Greets(Dog another)
        {
            Console.WriteLine("yess");
        }

        public override void Greets()
        {
            Console.WriteLine("yes");
        }
    }
}