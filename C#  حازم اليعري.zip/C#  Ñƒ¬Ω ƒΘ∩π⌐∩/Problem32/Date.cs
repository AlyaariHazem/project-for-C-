﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Problem32
{
    public class Date
    {
        private int Day;
        private int Month;
        private int Year;

        public Date(int day, int month, int year)
        {
            Day = day;
            Month = month;
            Year = year;
        }

        public void SetDay(int day)
        {
            Day = day;
        }

        public void SetMonth(int month)
        {
            Month = month;
        }

        public void SetYear(int year)
        {
            Year = year;        }

        public int GetDay()
        {
            return Day;
        }

        public int GetMonth()
        {
            return Month;
        }

        public int GetYear()
        {
            return Year;
        }

        public string ToString()
        {
            return new DateTime(Year, Month, Day).ToShortDateString();
        }
    }
}