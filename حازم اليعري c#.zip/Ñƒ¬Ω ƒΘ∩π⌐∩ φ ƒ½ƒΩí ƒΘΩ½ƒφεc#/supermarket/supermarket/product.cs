﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace supermarket
{
    class Product
    {
        protected int ProductId { get; set; }
        public string Name { get; set; }
        public double Price { get; set; }
        public int Quantity { get; set; }

        public Product(int productId, string name, double price, int quantity)
        {
            ProductId = productId;
            Name = name;
            Price = price;
            Quantity = quantity;
        }
        public Product(int num) { }
        public void choose()
        {
            Console.WriteLine("1-add products \n 2-delete products \n display products ");
        }
        public void AddProduct()
        {

        }
        public void DeleteProduct()
        {

        }
        public void DisplayProduct()
        {

        }


    }
    
}
