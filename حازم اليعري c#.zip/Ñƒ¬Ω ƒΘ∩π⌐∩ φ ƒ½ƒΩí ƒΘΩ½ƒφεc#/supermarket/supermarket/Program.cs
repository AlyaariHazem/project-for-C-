﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace supermarket
{
    // this class for Adminstritor #################################################
    class Admin
    {
       public string Name;
        public int Password { get; set; }

             // athantcation and verify #################
        public int verify(string name,int passowrd)
        { 
            if (name == "Hazem" && passowrd == 123)
            {
                return 1;
                
            }
            else
            {

               
                return 0;
            }
        }
        public void mange()
        {
            int AdminInput;
            Console.WriteLine("1-products \n2-costumers  \n3-order  \n4-Invoice");
        adinput: try
            {
                AdminInput = int.Parse(Console.ReadLine());
            }
            catch
            {
                goto adinput;
            }
            switch (AdminInput)
            {
                case 1:
                    Product manage_product = new Product(AdminInput);
                    manage_product.choose();
                    break;
                case 2:
                    break;
                case 3:
                    break;
                case 4:
                    break;
                default:
                    Console.WriteLine("sorry Enter number 1-4 ");
                    goto adinput;
                    break;
            }
        }

        public void DisplayInfo()
        {
            Console.WriteLine($"Name: {Name}");
            Console.WriteLine($"Email: {Password}");
        }
    }
    class Customer
    {
        public int CustomerPhone { get; set; }
        public string Name { get; set; }
        public string Password { get; set; }

        public Customer(int customerPhone, string name, string password)
        {
            CustomerPhone = customerPhone;
            Name = name;
            this.Password = password;
        }

        public void DisplayInfo()
        {
            Console.WriteLine($"Customer ID: {CustomerPhone}");
            Console.WriteLine($"Name: {Name}");
            Console.WriteLine($"Email: {Password}");
        }
    }

    // this class for product

    // this class for order
    class Order
    {
        public int OrderId { get; set; }
        public Customer Customer { get; set; }
        public Product Product { get; set; }
        public int Quantity { get; set; }
        public DateTime OrderDate { get; set; }

        public Order(int orderId, Customer customer, Product product, int quantity, DateTime orderDate)
        {
            OrderId = orderId;
            Customer = customer;
            Product = product;
            Quantity = quantity;
            OrderDate = orderDate;
        }

        public void DisplayInfo()
        {
            Console.WriteLine($"Order ID: {OrderId}");
            Console.WriteLine("Customer Information:");
            Customer.DisplayInfo();
            Console.WriteLine("Product Information:");
            Product.DisplayProduct();
            Console.WriteLine($"Quantity: {Quantity}");
            Console.WriteLine($"Order Date: {OrderDate}");
        }
    }

    // thid class for Invoice 
    class Invoice
    {
        public int InvoiceId { get; set; }
        public Order Order { get; set; }
        public Customer Customer { get; set; }
        public double TotalAmount { get; set; }
        public DateTime InvoiceDate { get; set; }

        public Invoice(int invoiceId, Order order, Customer customer, double totalAmount, DateTime invoiceDate)
        {
            InvoiceId = invoiceId;
            Order = order;
            Customer = customer;
            TotalAmount = totalAmount;
            InvoiceDate = invoiceDate;
        }

        public void DisplayInfo()
        {
            Console.WriteLine($"Invoice ID: {InvoiceId}");
            Console.WriteLine("Order Information:");
            Order.DisplayInfo();
            Console.WriteLine("Seller Information:");
            Customer.DisplayInfo();
            Console.WriteLine($"Total Amount: {TotalAmount:C}");
            Console.WriteLine($"Invoice Date: {InvoiceDate}");
        }
    }
    // this function verfiy
    class verfiy
    {

    }
    // this main function  
    class Program
    {
        static void Main()
        {
            Console.WriteLine("1-admin \n2-seller \n3-buyer");
validNumber: int input=0;
            try
            {
             input = int.Parse(Console.ReadLine());
            }
            catch (Exception e)
            {
                
            }
            
            switch(input)
            {
                case 1:
                    // display for adminstration #######################################################
                    Admin Ad = new Admin();
                    Console.Clear();
                    Console.WriteLine($" wellcome");
              again:
                    try
                    {
                        Console.WriteLine($" please enter your name ? ");
                        Ad.Name =Convert.ToString(Console.ReadLine());
                    }
                    catch
                    {
                        Console.WriteLine("sorry don't enter number or simboles ");
                        goto again;
                    }
                    try
                    {
                        Console.WriteLine("enter you password ? ");
                        Ad.Password = int.Parse(Console.ReadLine());
                    }
                    catch
                    {
                        
                        Console.Clear();
                        Console.WriteLine(" Invalid password or name try again !\n\n");
                        goto again;
                    }
                    int verify_return =Ad.verify(Ad.Name, Ad.Password);
                    if(verify_return==0)
                    {
                        Console.Clear();
                        Console.WriteLine("your name or password INVALID ");
                        goto again;
                    }
                    Ad.mange();
                    break;
                case 2: 
                    Console.WriteLine($" welcome our customer");
                    break;
                default:
                    Console.WriteLine($" sorry entter number valid       1-3 ");
                    goto validNumber;
                    break;
            }
            
        }
    }
}

